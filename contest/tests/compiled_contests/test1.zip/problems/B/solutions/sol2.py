x = input()
print(x.upper())

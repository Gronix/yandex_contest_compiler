x = input()
print(x)

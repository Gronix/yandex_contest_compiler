op = input()
x = int(input())
y = int(input())
if op == '+':
	print(x + y)
elif op == '-':
	print(x - y)
elif op == '*':
	print(x * y)
elif op == '/':
	print(x / y)
else:
	print("Неизвестный оператор")

